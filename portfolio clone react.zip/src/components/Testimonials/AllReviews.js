const allReviews =[
    {
        id:1,
        p:"I'm really happy I found Chase. He is responsive, efficient and thorough, and makes it super easy to wrangle my Shopify website. If you're looking for a great freelance web developer, this is your guy.",
        name:'Katie F.',
        post:'Ori Apparel',
    },
    {
        id:2,
        p:"Chase built and designed my blog for me about a year ago and I couldn't be happier with his work. He is so easy to work with, professional and always there when I need him. My business has increased immensely since hiring Chase and I will continue working with him and recommending him to my colleagues for years to come!",
        name:'Carissa S.',
        post:'BroccYourBody',
    },
    {
        id:3,
        p:"Chase is my go-to for all things web. He has been a huge asset to my business for 3 years. Chase is reliable, honest and great at what he does. Highly recommend!",
        name:'Katie W.',
        post:'Hydrate IV Bar',
    },
    {
        id:4,
        p:"We started looking for a freelance web developer last year and were fortunate to find Chase. He's been easy to work with since the very beginning: organized, responsive, and helpful. And always on time.",
        name:'Dana N.',
        post:'AUX Architecture',
    },
    {
        id:5,
        p:"Chase has been the freelance web developer for our feature film from the pitch stage, through production, to the marketing/distribution stage. Whenever a change has to be made, he always jumps on it. His design is fantastic and user-friendly and he is extremely collaborative. I won't use anyone else moving forward. WORK WITH HIM.",
        name:'Kelly B.',
        post:'Writer/Director',
    }
];
export default allReviews;